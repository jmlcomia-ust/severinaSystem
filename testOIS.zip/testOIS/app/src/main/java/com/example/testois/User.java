package com.example.testois;

public class User {
        String id;
        String name;
        String password;
}
