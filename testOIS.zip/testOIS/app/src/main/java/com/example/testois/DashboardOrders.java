package com.example.testois;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DashboardOrders extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_orders);
    }
}